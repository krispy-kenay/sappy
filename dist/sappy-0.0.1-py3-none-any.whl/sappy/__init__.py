"""This package makes interacting with SAP from python easier by providing some streamlined functionality """

from .client import Client

__author__ = "Yannick G."
__email__ = "study.gyannick@gmail.com"
__version__ = "0.1"